<div id="m_375604842389844652wrapper" dir="ltr" style="background-color:#f7f7f7;margin:0;padding:70px 0 70px 0;width:100%">
			<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">
				<tbody><tr>
					<td align="center" valign="top">
						<div id="m_375604842389844652template_header_image">
													</div>
						<span class="HOEnZb"><font color="#888888">
							</font></span><table border="0" cellpadding="0" cellspacing="0" width="600" id="m_375604842389844652template_container" style="background-color:#ffffff;border:1px solid #dedede;border-radius:3px">
							<tbody><tr>
								<td align="center" valign="top">

									<table border="0" cellpadding="0" cellspacing="0" width="600" id="m_375604842389844652template_header" style="background:#c82333;color:#ffffff;border-bottom:0;font-weight:bold;line-height:100%;vertical-align:middle;font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif;border-radius:3px 3px 0 0">
										<tbody><tr>
											<td id="m_375604842389844652header_wrapper" style="padding:15px 48px;display:block">
												<h1 style="color:#ffffff;font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif;font-size:30px;font-weight:300;line-height:150%;margin:0;text-align:left">
                          <?php echo $title ?>
                        </h1>
											</td>
										</tr>
									</tbody></table>

								</td>
							</tr>
							<tr>
								<td align="center" valign="top">

									<span class="HOEnZb"><font color="#888888">
										</font></span><span class="HOEnZb"><font color="#888888">
									</font></span><table border="0" cellpadding="0" cellspacing="0" width="600" id="m_375604842389844652template_body">
										<tbody><tr>
											<td valign="top" id="m_375604842389844652body_content" style="background-color:#ffffff">

												<span class="HOEnZb"><font color="#888888">
													</font></span><span class="HOEnZb"><font color="#888888">
												</font></span><table border="0" cellpadding="20" cellspacing="0" width="100%">
													<tbody><tr>
														<td valign="top" style="padding:48px 48px 48px">
                              <div class="">
                                  <?php echo $content ?>
                              </div>

                            <span class="HOEnZb"><font color="#888888">
														</font></span></td></tr></tbody></table><span class="HOEnZb"><font color="#888888">

											</font></span></td></tr></tbody></table><span class="HOEnZb"><font color="#888888">

								</font></span></td></tr>
							<tr>
								<td align="center" valign="top">

									<table border="0" cellpadding="10" cellspacing="0" width="600" id="m_375604842389844652template_footer">
										<tbody><tr>
											<td valign="top" style="padding:0">
												<table border="0" cellpadding="10" cellspacing="0" width="100%">
													<tbody><tr>
														<td colspan="2" valign="middle" id="m_375604842389844652credit" style="padding:0 48px 23px 48px;border:0;color:#c82333;font-family:Arial;font-size:12px;line-height:125%;text-align:center">
															<p>Euro Baker</p>
														</td>
													</tr>
												</tbody></table>
											</td>
										</tr>
									</tbody></table>

								</td>
							</tr>
						</tbody></table>
					</td>
				</tr>
			</tbody></table><div class="yj6qo"></div><div class="adL">
		</div></div>
