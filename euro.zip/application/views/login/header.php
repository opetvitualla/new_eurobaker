<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title;?></title>
    <link href="<?= base_url("assets/module/bootstrap/css/bootstrap.min.css")?>" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url("assets/css/login.css")?>">
    <link rel="stylesheet" href="<?= base_url("assets/css/preloader.css")?>">
    
</head>
<body>