<div class="modal fade discrepancy_modal" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" style="max-width:900px;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Discrepancy</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-body">
                    <div class="card-body">
                        <div class="cont-po">
                            <table class="table table-bordered po-table">
                                <thead>
                                    <tr>
                                        <td>Item Name</td>
                                        <td>Quantity</td>
                                        <td>Rcv. Qty</td>
                                        <td style="width: 122px;">Item Unit</td>
                                    </tr>
                                </thead>
                                <tbody class="table-po-body-received"> </tbody>
                            </table>
                            <div class="notes_disc">
                                <div class="fbold mt-4">Note:</div>
                                <div class="mt-3 txt_desc_note">
                                   
                                </div>
                                <hr>
                            </div>
                            <div class="form-actions">
                                <div class="card-body text-right ">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal"> Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>        